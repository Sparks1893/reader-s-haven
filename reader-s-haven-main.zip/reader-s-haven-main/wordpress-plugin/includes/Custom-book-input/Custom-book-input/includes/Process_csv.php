Process_csv.php
<?php

// --- Settings ---
ini_set('display_errors', 1); // Show errors for debugging (DISABLE in production)
error_reporting(E_ALL);       // Report all errors (DISABLE in production)
ini_set('auto_detect_line_endings', TRUE); // Helps with CSV files created on different OS (e.g., Mac classic vs Windows/Linux)

// --- Configuration ---
// IMPORTANT: Create this directory and make it writable by your web server (e.g., chmod 775)
$uploadDir = 'uploads/';
$allowedMimeTypes = ['text/csv', 'text/plain', 'application/vnd.ms-excel']; // Common MIME types for CSV
$maxFileSize = 10 * 1024 * 1024; // 10 MB limit (adjust as needed)

// --- Start HTML Output ---
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Goodreads Import Results</title>
    <style>
        body { font-family: sans-serif; line-height: 1.6; padding: 20px; }
        .error { color: red; font-weight: bold; }
        .success { color: green; font-weight: bold; }
        pre { background-color: #f4f4f4; border: 1px solid #ccc; padding: 10px; overflow-x: auto; }
        table { border-collapse: collapse; margin-top: 20px; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>

<h1>Goodreads Import Processing</h1>

<?php

// --- File Upload Handling ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['goodreads_file'])) {

    $file = $_FILES['goodreads_file'];

    // 1. Check for upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        echo "<p class='error'>File upload error code: " . $file['error'] . ". Please try again.</p>";
        goto end_page; // Jump to the end of the PHP block
    }

    // 2. Check file size
    if ($file['size'] > $maxFileSize) {
        echo "<p class='error'>Error: File size (" . round($file['size'] / 1024) . " KB) exceeds the limit of " . ($maxFileSize / 1024 / 1024) . " MB.</p>";
        goto end_page;
    }

    // 3. Check MIME type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mimeType, $allowedMimeTypes)) {
         echo "<p class='error'>Error: Invalid file type. Only CSV files are allowed. Detected type: " . htmlspecialchars($mimeType) . "</p>";
         goto end_page;
    }

    // 4. Ensure upload directory exists and is writable
    if (!is_dir($uploadDir)) {
        if (!mkdir($uploadDir, 0775, true)) { // Create recursively with appropriate permissions
             echo "<p class='error'>Error: Failed to create upload directory '{$uploadDir}'. Check server permissions.</p>";
             goto end_page;
        }
    }
    if (!is_writable($uploadDir)) {
         echo "<p class='error'>Error: The upload directory '{$uploadDir}' is not writable by the web server.</p>";
         goto end_page;
    }


    // 5. Move the uploaded file
    // Generate a safer filename to avoid conflicts and potential issues
    $safeFilename = uniqid('goodreads_import_', true) . '.csv';
    $destination = $uploadDir . $safeFilename;

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        echo "<p class='error'>Error: Failed to move uploaded file to the destination directory.</p>";
        goto end_page;
    }

    echo "<p class='success'>File uploaded successfully as: " . htmlspecialchars($safeFilename) . "</p>";
    echo "<hr>";

    // --- CSV Processing ---
    $allBooks = [];
    $header = null;
    $rowCount = 0; // Includes header row for line number reporting
    $processedBooks = 0;

    if (($handle = fopen($destination, 'r')) !== FALSE) {
        echo "<h2>Processing CSV File...</h2>";

        while (($row = fgetcsv($handle)) !== FALSE) {
            $rowCount++;

            // Treat the first row as the header
            if ($header === null) {
                // Clean up header names (lowercase, replace spaces/special chars with underscore)
                 $header = array_map(function($col) {
                    // Remove potential BOM (Byte Order Mark) from the first header
                    if (strpos($col, "\xEF\xBB\xBF") === 0) {
                        $col = substr($col, 3);
                    }
                    return strtolower(preg_replace('/[^a-z0-9_]+/', '_', trim($col)));
                 }, $row);

                 // Basic check if it looks like a Goodreads header
                 if (!in_array('book_id', $header) || !in_array('title', $header) || !in_array('author', $header)) {
                     echo "<p class='error'>Error: CSV file does not appear to have the expected Goodreads header columns (Book Id, Title, Author). Please check the file.</p>";
                     fclose($handle);
                     // Optional: Delete the invalid file
                     // unlink($destination);
                     goto end_page;
                 }
                continue; // Skip to the next data row
            }

            // Combine header keys with row values, ONLY if column counts match
             if (count($header) === count($row)) {
                try {
                    $bookRecord = array_combine($header, $row);
                    $allBooks[] = $bookRecord;
                    $processedBooks++;
                } catch (ValueError $e) {
                    // This catch block is needed for PHP 8.0+ if array_combine fails
                     echo "<p>Warning: Could not combine header and data on row {$rowCount}. Skipping row. Error: " . $e->getMessage() . "</p>";
                     echo "<pre>Header count: " . count($header) . ", Row count: " . count($row) . "\nHeaders: " . print_r($header, true) . "\nRow Data: " . print_r($row, true) . "</pre>";
                }

            } else {
                 echo "<p>Warning: Column count mismatch on row {$rowCount}. Header has " . count($header) . " columns, row has " . count($row) . ". Skipping row.</p>";
                 // Optionally log this row's data for debugging: print_r($row);
            }
        } // End while loop

        fclose($handle);
        ini_set('auto_detect_line_endings', FALSE); // Reset setting

        echo "<p class='success'>CSV Processing Complete. Processed {$processedBooks} book records.</p>";

        // --- Output Results / Further Processing ---
        if (!empty($allBooks)) {
            echo "<h3>Sample of Imported Books (First 10):</h3>";
            echo "<table>";
            echo "<thead><tr>";
            // Display some key headers
            $displayHeaders = ['book_id', 'title', 'author', 'my_rating', 'average_rating', 'publisher', 'binding', 'year_published', 'date_read', 'bookshelves'];
            foreach ($displayHeaders as $col) {
                // Check if the column actually exists in the imported header
                 if(in_array(strtolower(str_replace(' ','_',$col)), $header)){
                     echo "<th>" . htmlspecialchars(ucwords(str_replace('_',' ',$col))) . "</th>";
                 } else if (in_array($col, $header)) { // Check original name too
                     echo "<th>" . htmlspecialchars(ucwords(str_replace('_',' ',$col))) . "</th>";
                 }
            }
            echo "</tr></thead>";
            echo "<tbody>";

            $sampleBooks = array_slice($allBooks, 0, 10);
            foreach ($sampleBooks as $book) {
                echo "<tr>";
                 foreach ($displayHeaders as $col) {
                    $key = strtolower(str_replace(' ','_',$col)); // Use the cleaned key
                     if (isset($book[$key])) {
                         echo "<td>" . htmlspecialchars($book[$key]) . "</td>";
                    } else if (isset($book[$col])) { // Check original name too
                         echo "<td>" . htmlspecialchars($book[$col]) . "</td>";
                     } else {
                        // Handle cases where a selected display column might not be in *this specific* export
                        // (Though unlikely for the core ones listed)
                        echo "<td>N/A</td>";
                    }
                 }
                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";

            echo "<hr>";
            echo "<h3>Next Steps:</h3>";
            echo "<p>You now have an array named <code>\$allBooks</code> containing {$processedBooks} associative arrays (one for each book). You can now:</p>";
            echo "<ul>";
            echo "<li>Iterate through <code>\$allBooks</code> and insert/update records in your application's database.</li>";
            echo "<li>Perform data validation or cleaning on the imported fields.</li>";
            echo "<li>Display the imported library in a custom format.</li>";
            echo "</ul>";

            // Example: Show the structure of the first book's data
            echo "<h4>Data structure of the first imported book:</h4>";
            echo "<pre>";
            print_r($allBooks[0]);
            echo "</pre>";


        } else {
            echo "<p>No valid book records were found in the CSV file.</p>";
        }

        // Optional: Delete the uploaded file after successful processing
        // if (unlink($destination)) {
        //    echo "<p>Uploaded CSV file deleted successfully.</p>";
        // } else {
        //    echo "<p>Warning: Could not delete the uploaded CSV file '{$destination}'.</p>";
        // }

    } else {
        // Handle fopen failure
        ini_set('auto_detect_line_endings', FALSE); // Reset setting
        echo "<p class='error'>Error: Could not open the uploaded CSV file ('" . htmlspecialchars($destination) . "') for reading.</p>";
    }

} else {
    // Handle cases where the script is accessed directly without POST data or file upload
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
         echo "<p>This script should be accessed via the upload form.</p>";
    } else {
        echo "<p class='error'>No file was uploaded or there was an issue with the upload form submission.</p>";
    }
}

// Label for goto statement
end_page:

?>

<hr>
<p><a href="upload_form.html">Upload another file</a></p>

</body>
</html>