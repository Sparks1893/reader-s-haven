<?php
namespace Bookhive;

defined('ABSPATH') || exit;

/**
 * Class Helpers
 *
 * A central utility class used across the Bookhive ecosystem.
 * Provides sanitisation, template loading, logging, API helpers,
 * and common formatting functions.
 */
class Helpers
{
    /**
     * Initialise helper hooks (if needed).
     */
    public static function init(): void
    {
        // Example: custom filters or formatting functions.
        add_filter('bookhive_clean_text', [__CLASS__, 'clean_text']);
    }

    /* -------------------------------------------------------------
       SANITISATION HELPERS
    ------------------------------------------------------------- */

    public static function clean_text($value): string
    {
        return wp_kses_post(trim($value));
    }

    public static function clean_int($value): int
    {
        return intval($value);
    }

    public static function clean_bool($value): bool
    {
        return (bool)$value;
    }

    public static function clean_array($array): array
    {
        if (!is_array($array)) return [];
        return array_map('sanitize_text_field', $array);
    }

    public static function clean_url($url): string
    {
        return esc_url_raw($url);
    }

    /* -------------------------------------------------------------
       TEMPLATE LOADING
    ------------------------------------------------------------- */

    /**
     * Load a template from /templates/, with fallback.
     *
     * @param string $file  Template filename
     * @param array  $vars  Variables to extract into template scope
     * @return string
     */
    public static function load_template(string $file, array $vars = []): string
    {
        $path = BOOKHIVE_PATH . 'templates/' . $file;

        if (!file_exists($path)) {
            return "<!-- Template not found: {$file} -->";
        }

        ob_start();
        extract($vars, EXTR_SKIP);
        include $path;
        return ob_get_clean();
    }

    /* -------------------------------------------------------------
       JSON RESPONSE HELPERS (AJAX)
    ------------------------------------------------------------- */

    public static function success($data = []): void
    {
        wp_send_json([
            'success' => true,
            'data'    => $data,
        ]);
    }

    public static function error($message, $code = 400): void
    {
        wp_send_json([
            'success' => false,
            'error'   => $message,
            'code'    => $code,
        ]);
    }

    /* -------------------------------------------------------------
       LOGGING
    ------------------------------------------------------------- */

    public static function log($message): void
    {
        if (!WP_DEBUG) return;
        error_log('[BOOKHIVE] ' . print_r($message, true));
    }

    /* -------------------------------------------------------------
       PROFILE HELPERS
    ------------------------------------------------------------- */

    /**
     * Return a user’s display name with fallback.
     */
    public static function user_name($user_id): string
    {
        $user = get_userdata($user_id);
        if (!$user) return 'Unknown User';

        return $user->display_name ?: $user->user_login;
    }

    /**
     * Get profile metadata quickly with fallback.
     */
    public static function profile_field($user_id, $key, $default = '')
    {
        $value = get_user_meta($user_id, $key, true);
        return $value !== '' ? $value : $default;
    }

    /* -------------------------------------------------------------
       BOOK HELPERS
    ------------------------------------------------------------- */

    /**
     * Convert Google Books API data → PLM compatible array.
     */
    public static function google_book_to_plm($item): array
    {
        $info = $item['volumeInfo'] ?? [];

        return [
            'title'       => $info['title'] ?? '',
            'author'      => $info['authors'][0] ?? '',
            'isbn'        => $info['industryIdentifiers'][0]['identifier'] ?? '',
            'cover'       => $info['imageLinks']['thumbnail'] ?? '',
            'description' => $info['description'] ?? '',
            'published'   => $info['publishedDate'] ?? '',
            'page_count'  => $info['pageCount'] ?? '',
        ];
    }

    /* -------------------------------------------------------------
       API FETCH (Google Books / OpenLibrary)
    ------------------------------------------------------------- */

    /**
     * Fetch book data by ISBN using Google Books API
     */
    public static function fetch_google_books($isbn): array
    {
        $url = "https://www.googleapis.com/books/v1/volumes?q=isbn:" . urlencode($isbn);
        $response = wp_remote_get($url);

        if (is_wp_error($response)) {
            return [];
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);

        if (empty($data['items'][0])) {
            return [];
        }

        return self::google_book_to_plm($data['items'][0]);
    }

    /* -------------------------------------------------------------
       STATUS / LABEL HELPERS
    ------------------------------------------------------------- */

    public static function status_label($status): string
    {
        $labels = [
            'to-read'  => 'To Read',
            'reading'  => 'Reading',
            'completed'=> 'Completed',
            'dnf'      => 'Did Not Finish',
            'wishlist' => 'Wishlist',
        ];

        return $labels[$status] ?? ucfirst($status);
    }

    /**
     * Convert timestamp to pretty date (“2 days ago”).
     */
    public static function pretty_time($timestamp): string
    {
        return human_time_diff($timestamp, current_time('timestamp')) . ' ago';
    }

}
