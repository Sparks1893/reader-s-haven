<?php
namespace Bookhive\Models;

defined('ABSPATH') || exit;

class Profile
{
    /**
     * Get a profile row for a user
     */
    public static function get(int $user_id)
    {
        global $wpdb;

        return $wpdb->get_row(
            $wpdb->prepare("
                SELECT *
                FROM {$wpdb->prefix}bookhive_profiles
                WHERE user_id = %d
                LIMIT 1
            ", $user_id),
            ARRAY_A
        );
    }

    /**
     * Create or update profile fields
     */
    public static function save(int $user_id, array $data)
    {
        global $wpdb;

        $defaults = [
            'display_name' => '',
            'bio'          => '',
            'avatar_url'   => '',
            'location'     => '',
            'website'      => '',
        ];

        $data = wp_parse_args($data, $defaults);

        $exists = self::get($user_id);

        if ($exists) {
            return $wpdb->update(
                "{$wpdb->prefix}bookhive_profiles",
                $data,
                ['user_id' => $user_id]
            );
        }

        $data['user_id'] = $user_id;

        return $wpdb->insert("{$wpdb->prefix}bookhive_profiles", $data);
    }
}
