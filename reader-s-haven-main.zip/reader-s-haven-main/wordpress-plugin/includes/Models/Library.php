<?php
namespace Bookhive\Models;

defined('ABSPATH') || exit;

class Library
{
    public static function get_all(int $user_id)
    {
        global $wpdb;

        return $wpdb->get_results(
            $wpdb->prepare("
                SELECT *
                FROM {$wpdb->prefix}bookhive_library
                WHERE user_id = %d
                ORDER BY updated_at DESC
            ", $user_id),
            ARRAY_A
        );
    }

    public static function get_entry(int $user_id, int $book_id)
    {
        global $wpdb;

        return $wpdb->get_row(
            $wpdb->prepare("
                SELECT *
                FROM {$wpdb->prefix}bookhive_library
                WHERE user_id = %d AND book_id = %d
                LIMIT 1
            ", $user_id, $book_id),
            ARRAY_A
        );
    }

    public static function add(int $user_id, int $book_id)
    {
        global $wpdb;

        if (self::get_entry($user_id, $book_id)) {
            return true; // already exists
        }

        return $wpdb->insert(
            "{$wpdb->prefix}bookhive_library",
            [
                'user_id' => $user_id,
                'book_id' => $book_id,
                'status'  => 'to-read',
            ]
        );
    }

    public static function update_status(int $user_id, int $book_id, string $status)
    {
        global $wpdb;

        return $wpdb->update(
            "{$wpdb->prefix}bookhive_library",
            ['status' => $status],
            ['user_id' => $user_id, 'book_id' => $book_id]
        );
    }

    public static function update_rating(int $user_id, int $book_id, int $rating)
    {
        global $wpdb;

        return $wpdb->update(
            "{$wpdb->prefix}bookhive_library",
            ['rating' => $rating],
            ['user_id' => $user_id, 'book_id' => $book_id]
        );
    }

    public static function remove(int $user_id, int $book_id)
    {
        global $wpdb;

        return $wpdb->delete(
            "{$wpdb->prefix}bookhive_library",
            ['user_id' => $user_id, 'book_id' => $book_id]
        );
    }
}
