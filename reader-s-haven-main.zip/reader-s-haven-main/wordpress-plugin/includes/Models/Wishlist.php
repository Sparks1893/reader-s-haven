<?php
namespace Bookhive\Models;

defined('ABSPATH') || exit;

class Wishlist
{
    public static function get(int $user_id)
    {
        global $wpdb;

        return $wpdb->get_results(
            $wpdb->prepare("
                SELECT w.*, p.post_title AS title
                FROM {$wpdb->prefix}bookhive_wishlist w
                LEFT JOIN {$wpdb->posts} p ON p.ID = w.book_id
                WHERE w.user_id = %d
                ORDER BY w.added_at DESC
            ", $user_id),
            ARRAY_A
        );
    }

    public static function add(int $user_id, int $book_id)
    {
        global $wpdb;

        return $wpdb->replace(
            "{$wpdb->prefix}bookhive_wishlist",
            [
                'user_id' => $user_id,
                'book_id' => $book_id,
            ]
        );
    }

    public static function remove(int $user_id, int $book_id)
    {
        global $wpdb;

        return $wpdb->delete(
            "{$wpdb->prefix}bookhive_wishlist",
            ['user_id' => $user_id, 'book_id' => $book_id]
        );
    }
}
