<?php
namespace Bookhive;

defined('ABSPATH') || exit;

class Plugin
{
    public function init(): void
    {
        Helpers::init();
        Database::init();

        // Load subsystems
        User\User::init();
        User\User_Profile::init();
        User\User_Auth::init();
        User\User_Avatars::init();
        User\User_Settings::init();

        Library\Library::init();
        Library\Library_Actions::init();
        Library\ISBN_Importer::init();
        Library\Library_Display::init();
        Library\Wishlist::init();

        Achievements\Achievements::init();
        Achievements\Badge_Engine::init();

        Community\Feed::init();
        Community\Comments::init();
        Community\Likes::init();

        Clubs\Clubs::init();
        Clubs\Club_Profile::init();
        Clubs\Club_Members::init();
        Clubs\Club_Posts::init();

        Pages\Register_Page::init();
        Pages\Login_Page::init();
        Pages\Hub_Page::init();
        Pages\Profile_Page::init();

        // Shared assets for all
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    public function enqueue_assets()
    {
        wp_enqueue_style('bookhive-style', BOOKHIVE_URL . 'assets/css/bookhive-style.css', [], BOOKHIVE_VERSION);
        wp_enqueue_script('bookhive-core', BOOKHIVE_URL . 'assets/js/bookhive-core.js', ['jquery'], BOOKHIVE_VERSION, true);

        wp_localize_script('bookhive-core', 'BookhiveAjax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('bookhive_nonce'),
        ]);
    }
}
