<?php
namespace Bookhive;

defined('ABSPATH') || exit;

/**
 * Bookhive Database Manager
 * Creates and upgrades all database tables.
 */
class Database
{
    const DB_VERSION = '1.0.0';
    const OPTION_KEY = 'bookhive_db_version';

    /**
     * Called during plugin activation.
     */
    public static function activate()
    {
        self::create_tables();
        update_option(self::OPTION_KEY, self::DB_VERSION);
    }

    /**
     * Called during plugin updates (future versions).
     */
    public static function maybe_upgrade()
    {
        $installed = get_option(self::OPTION_KEY);
        if ($installed !== self::DB_VERSION) {
            self::create_tables();
            update_option(self::OPTION_KEY, self::DB_VERSION);
        }
    }

    /**
     * Safe WP table creation with foreign keys.
     */
    private static function create_tables()
    {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = "DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ENGINE=InnoDB";

        $tables = [];

        // ---------------------------------------------------------------------
        // 1. USER PROFILES
        // ---------------------------------------------------------------------
        $tables[] = "
        CREATE TABLE {$wpdb->prefix}bookhive_profiles (
            user_id BIGINT UNSIGNED NOT NULL,
            display_name VARCHAR(200),
            bio TEXT,
            avatar_url VARCHAR(500),
            location VARCHAR(200),
            website VARCHAR(300),
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id),
            CONSTRAINT fk_profile_user
                FOREIGN KEY (user_id)
                REFERENCES {$wpdb->users}(ID)
                ON DELETE CASCADE
        ) $charset;
        ";

        // ---------------------------------------------------------------------
        // 2. USER LIBRARY (collection of books)
        // ---------------------------------------------------------------------
        $tables[] = "
        CREATE TABLE {$wpdb->prefix}bookhive_library (
            id BIGINT UNSIGNED AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            book_id BIGINT UNSIGNED NOT NULL,
            status ENUM('to-read','reading','paused','completed','dnf') DEFAULT 'to-read',
            rating TINYINT,
            spice_level TINYINT,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            INDEX (user_id),
            INDEX (book_id),
            CONSTRAINT fk_library_user
                FOREIGN KEY (user_id)
                REFERENCES {$wpdb->users}(ID)
                ON DELETE CASCADE,
            CONSTRAINT fk_library_book
                FOREIGN KEY (book_id)
                REFERENCES {$wpdb->posts}(ID)
                ON DELETE CASCADE
        ) $charset;
        ";

        // ---------------------------------------------------------------------
        // 3. WISHLIST
        // ---------------------------------------------------------------------
        $tables[] = "
        CREATE TABLE {$wpdb->prefix}bookhive_wishlist (
            id BIGINT UNSIGNED AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            book_id BIGINT UNSIGNED NOT NULL,
            added_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE (user_id, book_id),
            CONSTRAINT fk_wish_user
                FOREIGN KEY (user_id)
                REFERENCES {$wpdb->users}(ID)
                ON DELETE CASCADE,
            CONSTRAINT fk_wish_book
                FOREIGN KEY (book_id)
                REFERENCES {$wpdb->posts}(ID)
                ON DELETE CASCADE
        ) $charset;
        ";

        // ---------------------------------------------------------------------
        // 4. REVIEWS
        // ---------------------------------------------------------------------
        $tables[] = "
        CREATE TABLE {$wpdb->prefix}bookhive_reviews (
            id BIGINT UNSIGNED AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            book_id BIGINT UNSIGNED NOT NULL,
            rating TINYINT,
            spice_level TINYINT,
            review_text TEXT,
            contains_spoilers TINYINT(1) DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            INDEX (book_id),
            CONSTRAINT fk_review_user
                FOREIGN KEY (user_id)
                REFERENCES {$wpdb->users}(ID)
                ON DELETE CASCADE,
            CONSTRAINT fk_review_book
                FOREIGN KEY (book_id)
                REFERENCES {$wpdb->posts}(ID)
                ON DELETE CASCADE
        ) $charset;
        ";

        // ---------------------------------------------------------------------
        // 5. READING PROGRESS LOG
        // ---------------------------------------------------------------------
        $tables[] = "
        CREATE TABLE {$wpdb->prefix}bookhive_progress (
            id BIGINT UNSIGNED AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            book_id BIGINT UNSIGNED NOT NULL,
            percent SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            CONSTRAINT fk_progress_user
                FOREIGN KEY (user_id)
                REFERENCES {$wpdb->users}(ID)
                ON DELETE CASCADE,
            CONSTRAINT fk_progress_book
                FOREIGN KEY (book_id)
                REFERENCES {$wpdb->posts}(ID)
                ON DELETE CASCADE
        ) $charset;
        ";

        // ---------------------------------------------------------------------
        // 6. ACHIEVEMENTS
        // ---------------------------------------------------------------------
        $tables[] = "
        CREATE TABLE {$wpdb->prefix}bookhive_achievements (
            id BIGINT UNSIGNED AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            badge_key VARCHAR(100) NOT NULL,
            earned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE (user_id, badge_key),
            CONSTRAINT fk_achievement_user
                FOREIGN KEY (user_id)
                REFERENCES {$wpdb->users}(ID)
                ON DELETE CASCADE
        ) $charset;
        ";

        // ---------------------------------------------------------------------
        // 7. COMMUNITY FEED
        // ---------------------------------------------------------------------
        $tables[] = "
        CREATE TABLE {$wpdb->prefix}bookhive_feed (
            id BIGINT UNSIGNED AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            activity_type VARCHAR(50) NOT NULL,
            message TEXT,
            related_book BIGINT UNSIGNED,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            INDEX (user_id),
            CONSTRAINT fk_feed_user
                FOREIGN KEY (user_id)
                REFERENCES {$wpdb->users}(ID)
                ON DELETE CASCADE,
            CONSTRAINT fk_feed_book
                FOREIGN KEY (related_book)
                REFERENCES {$wpdb->posts}(ID)
                ON DELETE SET NULL
        ) $charset;
        ";

        // ---------------------------------------------------------------------
        // 8. BOOK CLUBS
        // ---------------------------------------------------------------------
        $tables[] = "
        CREATE TABLE {$wpdb->prefix}bookhive_clubs (
            id BIGINT UNSIGNED AUTO_INCREMENT,
            owner_id BIGINT UNSIGNED NOT NULL,
            name VARCHAR(200) NOT NULL,
            description TEXT,
            privacy ENUM('public','private') DEFAULT 'public',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            CONSTRAINT fk_club_owner
                FOREIGN KEY (owner_id)
                REFERENCES {$wpdb->users}(ID)
                ON DELETE CASCADE
        ) $charset;
        ";

        // ---------------------------------------------------------------------
        // 9. CLUB MEMBERS
        // ---------------------------------------------------------------------
        $tables[] = "
        CREATE TABLE {$wpdb->prefix}bookhive_club_members (n
            id BIGINT UNSIGNED AUTO_INCREMENT,
            club_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            role ENUM('owner','admin','member') DEFAULT 'member',
            joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE (club_id, user_id),
            CONSTRAINT fk_club_member_club
                FOREIGN KEY (club_id)
                REFERENCES {$wpdb->prefix}bookhive_clubs(id)
                ON DELETE CASCADE,
            CONSTRAINT fk_club_member_user
                FOREIGN KEY (user_id)
                REFERENCES {$wpdb->users}(ID)
                ON DELETE CASCADE
        ) $charset;
        ";

        // ---------------------------------------------------------------------
        // 10. CLUB POSTS (like mini feed inside clubs)
        // ---------------------------------------------------------------------
        $tables[] = "
        CREATE TABLE {$wpdb->prefix}bookhive_club_posts (
            id BIGINT UNSIGNED AUTO_INCREMENT,
            club_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            content TEXT NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            CONSTRAINT fk_club_post_club
                FOREIGN KEY (club_id)
                REFERENCES {$wpdb->prefix}bookhive_clubs(id)
                ON DELETE CASCADE,
            CONSTRAINT fk_club_post_user
                FOREIGN KEY (user_id)
                REFERENCES {$wpdb->users}(ID)
                ON DELETE CASCADE
        ) $charset;
        ";

        // ---------------------------------------------------------------------
        // EXECUTE ALL TABLES
        // ---------------------------------------------------------------------
        foreach ($tables as $sql) {
            dbDelta($sql);
        }
    }
}
